export { default } from './image';
