import PropTypes from 'prop-types';
import { sub } from 'date-fns';
import { useRef, useState, useCallback, useMemo, useEffect } from 'react';
// @mui
import Stack from '@mui/material/Stack';
import InputBase from '@mui/material/InputBase';
import IconButton from '@mui/material/IconButton';
// routes
import { paths } from 'src/routes/paths';
import { useRouter,useSearchParams } from 'src/routes/hooks';
// hooks
import { useMockedUser } from 'src/hooks/use-mocked-user';
// utils
import uuidv4 from 'src/utils/uuidv4';
// api
import { sendMessage, createConversation } from 'src/api/chat';
// components
import Iconify from 'src/components/iconify';
import { io } from 'socket.io-client';

// ----------------------------------------------------------------------

export default function ChatMessageInput({
  recipients,
  onAddRecipients,
  //
  disabled,
  selectedConversationId,
  selecteddepartmentConversationId,
  selecteditem_idConversationId,
}) {
  console.log("Data",selectedConversationId,selecteddepartmentConversationId,selecteditem_idConversationId);

 

  const router = useRouter();

  const { user } = useMockedUser();

  const fileRef = useRef(null);

  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);

  const [socket, setSocket] = useState(null);
 
  const [error, setError] = useState('');
  const [blockedUser, setBlockedUser] = useState(false); 

  useEffect(() => {

          const newSocket = io('http://51.21.81.149:3000', {
              auth: {
                  token: user.token
              }
          });

          newSocket?.on('connect', () => {
              console.log('Connected to server');
              newSocket.emit('add user', { client: user.id, conversation: selectedConversationId, department_id: selecteddepartmentConversationId, item_id: selecteditem_idConversationId });
          });

          newSocket?.on('message', (data) => {
              console.log('Received message data:', data);
              if (data && data.message) {
                setMessages(prevMessages => [...prevMessages, data]);
              } else {
                  console.error('Received invalid message data:', data);
              }
          });
          newSocket?.on('user_blocked', (blockedUserId) => {
              console.log(blockedUserId)
              if ((blockedUserId.blocked_user_id === selectedConversationId && blockedUserId.from_id===user.id)||
              ((blockedUserId.blocked_user_id === user.id && blockedUserId.from_id===selectedConversationId))
              ) {
                  console.log('blockeeed')
                  setBlockedUser(true);
              }
          });
          newSocket?.on('user_unblocked', (unblockedUserId) => {
              console.log(unblockedUserId)

              if ((unblockedUserId.blocked_user_id === selectedConversationId && unblockedUserId.from_id===user.id)||
              ((unblockedUserId.blocked_user_id === user.id && unblockedUserId.from_id===selectedConversationId))
              ) {
                  console.log('unblockeeed')
                  setBlockedUser(false);
              }
          });

          newSocket?.on('disconnect', () => {
              console.log('Disconnected from server');
          });

          setSocket(newSocket);

          // return () => {
          //     newSocket?.disconnect();
          // };
      
  }, []);

  const sendMessage = () => {
      if (socket && message.trim() !== '') {
          const messageData = {
              to_id: selectedConversationId,
              from_id: user.id,
              message: message,
              departments_id: selecteddepartmentConversationId,
              item_id: selecteditem_idConversationId
          };
          socket.emit('send_message', messageData);
          setMessage('');
      } else {
          setError('Token is required to send a message.');
      }
  };

  const blockUser = () => {
      if (socket) {
          socket.emit('block_user', { from_id:user.id,blocked_user_id: selectedConversationId });
          setBlockedUser(true);
      }
  };

  const unblockUser = () => {
      if (socket) {
          socket.emit('unblock_user', { from_id:user.id,blocked_user_id: selectedConversationId });
          setBlockedUser(false);
      }
  };



  const handleChangeMessage = useCallback((event) => {
    setMessage(event.target.value);
  }, []);


  

  return (
    <>
      <InputBase
        value={message}
        // onKeyUp={handleSendMessage}
        onChange={handleChangeMessage}
        placeholder="Type a message"
        disabled={disabled}
        // startAdornment={
        //   <IconButton>
        //     <Iconify icon="eva:smiling-face-fill" />
        //   </IconButton>
        // }
        endAdornment={
          <Stack direction="row" sx={{ flexShrink: 0 }}>
            {/* <IconButton onClick={handleAttach}>
              <Iconify icon="solar:gallery-add-bold" />
            </IconButton> */}
            {/* <IconButton onClick={handleAttach}>
              <Iconify icon="eva:attach-2-fill" />
            </IconButton> */}
          <IconButton onClick={sendMessage}>
    <Iconify icon="solar:microphone-bold" />
  </IconButton>
          </Stack>
        }
        sx={{
          px: 1,
          height: 56,
          flexShrink: 0,
          borderTop: (theme) => `solid 1px ${theme.palette.divider}`,
        }}
      />

    </>
  );
}

ChatMessageInput.propTypes = {
  disabled: PropTypes.bool,
  onAddRecipients: PropTypes.func,
  recipients: PropTypes.array,
  selectedConversationId: PropTypes.string,
  selecteditem_idConversationId: PropTypes.string,
  selecteddepartmentConversationId: PropTypes.string,
};
