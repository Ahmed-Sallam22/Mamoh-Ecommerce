export { default as ContactForm } from './contact-view';

