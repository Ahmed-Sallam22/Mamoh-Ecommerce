/* eslint-disable no-use-before-define */

import PropTypes from "prop-types";
import * as Yup from "yup";
import { useCallback, useMemo, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
// @mui
import LoadingButton from "@mui/lab/LoadingButton";
import Box from "@mui/material/Box";

import Card from "@mui/material/Card";
import Stack from "@mui/material/Stack";
import Switch from "@mui/material/Switch";

import Grid from "@mui/material/Unstable_Grid2";
import CardHeader from "@mui/material/CardHeader";
import Typography from "@mui/material/Typography";

import FormControlLabel from "@mui/material/FormControlLabel";
// routes
import { paths } from "src/routes/paths";
// hooks
import { useResponsive } from "src/hooks/use-responsive";
// _mock
// import { NumbersID, countriesData } from "src/_mock";
import { createBusiness, updateBusiness } from "src/api/Business";
// components
// import { useSnackbar } from "src/components/snackbar";
import { useRouter } from "src/routes/hooks";
import FormProvider, {
  RHFSelect,
  RHFUpload,
  RHFTextField,
  RHFUploadAvatar,
  RHFAutocomplete,
} from "src/components/hook-form";
import axios from "axios";
import { CounteryCitesBusines } from "./Business-Countery-cites";
import BusinessMap from "./Business-Map-Location";
import { useAuthContext } from "src/auth/hooks";
import { fData } from "src/utils/format-number";
import { endpoints } from "src/utils/axios";
import { enqueueSnackbar } from "notistack";
import { useGetBusinessByCategories, useGetBusinessByCategorieschildrens } from "src/api/bussiness";
import { useGETFillterColor } from "src/api/product";
import { Chip, CircularProgress, TextField } from "@mui/material";
import { useLocales } from "src/locales";
// ----------------------------------------------------------------------

export default function BusinessNewEditForm({ currentBusiness }) {
  const router = useRouter();
  const auth = useAuthContext();

  const mdUp = useResponsive("up", "md");
  const {t}=useLocales()

  // const { enqueueSnackbar } = useSnackbar();
  

  const NewProductSchema = Yup.object().shape({
    name: Yup.string()
    .required(t("Name is required"))
    .max(100, t("Name must be at most 100 characters"))  
    .matches(/^([a-zA-Z\u0600-\u06FF]+[\s\p{P}]*)|([\s\p{P}]*[a-zA-Z\u0600-\u06FF]+[\s\p{P}]*)|([\s\p{P}]*[a-zA-Z\u0600-\u06FF]+)$/, t('Please enter at least one character'))
    ,
   
    // images: Yup.array().min(1, "Images is required"),
    // image: Yup.string().required("Image is required"),
    address: Yup.string()
    .required(t('Address is required'))
    .matches(/^([a-zA-Z\u0600-\u06FF]+[\s\p{P}]*)|([\s\p{P}]*[a-zA-Z\u0600-\u06FF]+[\s\p{P}]*)|([\s\p{P}]*[a-zA-Z\u0600-\u06FF]+)$/, t('Please enter at least one character')),
    description: Yup.string().required(t("description is required"))
    .matches(/^([a-zA-Z\u0600-\u06FF]+[\s\p{P}]*)|([\s\p{P}]*[a-zA-Z\u0600-\u06FF]+[\s\p{P}]*)|([\s\p{P}]*[a-zA-Z\u0600-\u06FF]+)$/, t('Please enter at least one character'))      .max(500,t("description must be at most 500 characters")),
    mobile_number: Yup.string()
    .required(t("Mobile number is required"))
    .matches(
      /^[0-9]{5,15}$/, // Adjust the regular expression according to your requirements
      t("Invalid phone number")
    )
    ,
      
 email: Yup.string().required(t('Email is required'))
    .matches(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
     t('Invalid email format')
    ),
    facebook: Yup.string()
    .matches(
      /^$|(https?:\/\/)?(www\.)?facebook.com\/[a-zA-Z0-9.]*/,
      t('Please enter a valid Facebook link')
    ),
    website: Yup.string()
    .matches(
      /^$|(https?:\/\/)?(www\.)?([a-zA-Z0-9-]+\.){1,}[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?/,
      t('Please enter a valid website link')
    )
,
snapchat: Yup.string()
    .matches(
      /^$|https?:\/\/(?:www\.)?snapchat\.com\/add\/[a-zA-Z0-9-_]+(?:\?[\w=&-]+)?/,
      t('Please enter a valid snapchat link')
    )
,
instagram: Yup.string()
    .matches(
      /^$|(https?:\/\/)?(www\.)?instagram\.com\/[a-zA-Z0-9_]+\/?(\?[\w=&-]+)?/,
      t('Please enter a valid instagram link')
    )
,
whatsapp:Yup.string()
.matches(
  /^$|^[0-9]{5,15}$/,
  t("Invalid phone number")
),
store_id:Yup.string().required(t("Store code is required"))


  });

  const defaultValues = useMemo(
    () => ({
      name: currentBusiness?.name || "",
      description: currentBusiness?.description || "",
     
      image: currentBusiness?.image || '',
      images: currentBusiness?.images || [],
      mobile_number: currentBusiness?.mobile_number || "",
      facebook: currentBusiness?.facebook || "",
      website: currentBusiness?.website || "",
      instagram: currentBusiness?.instagram || "",
      email: currentBusiness?.email || "",
      whatsapp: currentBusiness?.whatsapp || "",
      snapchat: currentBusiness?.snapchat || "",
      address: currentBusiness?.address || "",
      country_id: currentBusiness?.country_id || "",
      city_id: currentBusiness?.city_id || "",
      lat: currentBusiness?.lat || 4748,
      lng: currentBusiness?.long || 1425,
      store_id:currentBusiness?.store_id||null ,
      is_store_id_visible : 1,
      currencies:currentBusiness?.currencies||2
      
    }),
    [currentBusiness]
  );
  const methods = useForm({
    resolver: yupResolver(NewProductSchema),
    defaultValues,
  });
  const [counteries, setCounteries] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [selectedCity, setSelectedCity] = useState(null);

  const {
    reset,
    watch,
    setValue,
    handleSubmit,
    trigger,
    formState: { isSubmitting },
  } = methods;

  const values = watch();


  useEffect(() => {
    const fetchCountries = async () => {
      try {
        const response = await axios.get('https://tapis.ma-moh.com/api/countries', {
       
        });

        setCounteries(response.data.data);
      } catch (error) {
        console.error('Error fetching countries:', error);
      }
    };

    fetchCountries();
    
    if (currentBusiness) {
      const fetchCities = async () => {
        try {
          const response = await axios.get(`https://tapis.ma-moh.com/api/cities?&country_id=${currentBusiness?.country_id}`);
          setCities(response.data.data);
          setSelectedCountry(currentBusiness?.country_id);
          setSelectedCity(currentBusiness?.city_id);
          reset(defaultValues);
        } catch (error) {
          console.error('Error fetching cities:', error);
        }
      };
    
      fetchCities();
    }
  }, [currentBusiness, defaultValues, reset]);
  const handleCountryChange = async (e) => {
    
    const countryId = parseInt(e.target.value, 10);
    setValue('country_id',countryId)

    setSelectedCountry(countryId);
    handlereigionChange(countryId)
    // Fetch the list of cities based on the selected country
    try {
      const response = await axios.get(`https://tapis.ma-moh.com/api/cities?&country_id=${countryId}`, {
     
      });

      setCities(response.data.data);

    } catch (error) {
      console.error('Error fetching cities:', error);
    }
  };

  const [Rigion, setRigion] = useState();
  const handlereigionChange = async (countryId) => {    
    try {
      const response = await axios.get(`https://tapis.ma-moh.com/api/regions?active=1&country_id=${countryId}`, {
     
      });
      setRigion(response.data.data);

    } catch (error) {
      console.error('Error fetching cities:', error);
    }
  };
  

  const [displayMap, setdisplayMap] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState(null);

  const handleLocationChange = (location) => {
    setSelectedLocation(location);
    if (selectedLocation) {
      setValue("lat", location.lat);
      setValue("lng", location.lng);
    }
  };

  const butonLocation = () => {
    setdisplayMap(!displayMap);
  };
  const slectLocation = () => {
    setdisplayMap(!displayMap);
  };

  const handleCityChange = (e) => {
    const cityId = parseInt(e.target.value, 10);
    setSelectedCity(cityId);
    setValue('city_id', cityId); 
  };
  const [SelectedRegion, setSelectedRegion] = useState();
  const handleRegionChange = (e) => {
    const RegionId = parseInt(e.target.value, 10);
    setSelectedRegion(RegionId);
    setValue('region_id', RegionId); 
  };
  const [isFoodStaff, setIsFoodStaff] = useState(false); // Initial state is unchecked (false)
  const handleSwitchChange = (event) => {
    
    setIsFoodStaff(event.target.checked); 

setValue('is_food_stuff', event.target.checked ? 1 : 0);
};
  const onSubmit = handleSubmit(async (formData) => {
    const combinedValues = `${categoriesid},${categoriesidParent}`;
    formData.categories=combinedValues;
    formData.business_department_id = 1;
    if (currentBusiness) {
      try {
        const {success ,data} = await updateBusiness(
          currentBusiness.id,
          formData
        );
        if (success) {
          enqueueSnackbar(" Business updated successfully!");
          router.push(paths.dashboard.Stores.root);
        } else {
          console.error("Failed to update business:", data.error);
        }
      } catch (error) {
        console.error("An error occurred during business update:", error);
      }
    } else {
      formData.lat = selectedLocation ? selectedLocation.lat : null;
      formData.lng = selectedLocation ? selectedLocation.lng : null;

      try {
        const response = await axios.post(
          `https://tapis.ma-moh.com${endpoints.Business.create}`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
              Authorization: `Bearer ${auth?.user?.accessToken}`,
            },
          }
        );
        enqueueSnackbar("Create success!");
        reset();
        router.push(paths.dashboard.Stores.root);
        console.info("DATA", response);
      } catch (error) {
        console.error(error);
        enqueueSnackbar("Error ", { variant: "error" });
      }
      
    }
  });

 
  // const [isStoreIdVisible, setIsStoreIdVisible] = useState(false);
  async function handleDropCover(acceptedFiles) {
    if (currentBusiness) {
      let file = acceptedFiles[0];
      const newFile = Object.assign(file, {
        preview: URL.createObjectURL(file),
      });
      const data = {
        image_file_name: newFile,
        imageable_type: "Business",
        imageable_id: currentBusiness.id,
      };
      setValue("image", newFile.preview);
      try {
        const response = await axios.post(
          "https://tapis.ma-moh.com/api/images/create",
          data,
          {
            headers: {
              "Content-Type": "multipart/form-data",
              Authorization: `Bearer ${auth?.user?.accessToken}`,
            },
          }
        );

        setValue("image", response?.data?.data?.image);
      } catch (error) {
        console.error("Error uploading image:", error);
      }
    } else {
      const file = acceptedFiles[0]; // Get the first file from acceptedFiles
      const newFile = Object.assign(file, {
        preview: URL.createObjectURL(file),
      });
      if (file) {
        setValue("image", newFile);
      }
    }
  }
 
 
  const handleDrop = useCallback(
    (acceptedFiles) => {
      const files = values.images || [];

      const newFiles = acceptedFiles.map((file) =>
        Object.assign(file, {
          preview: URL.createObjectURL(file),
        })
      );

      setValue("images", [...files, ...newFiles], { shouldValidate: true });
    },
    [setValue, values.images]
  );

  const handleRemoveFile = useCallback(
    (inputFile) => {
      const filtered =
        values.images && values.images?.filter((file) => file !== inputFile);
      setValue("images", filtered);
    },
    [setValue, values.images]
  );

  const handleRemoveAllFiles = useCallback(() => {
    setValue("images", []);
  }, [setValue]);

  

 
const [categoriesid, setcategoriesid] = useState('');
const [categoriesidParent, setcategoriesidParent] = useState();
  const handleCategoriesChange = (e, newValue) => {
    const categorYID = parseInt(e.target.value, 10);
    setcategoriesid(categorYID);
    setValue('categories', categorYID);  
  };
  const handleCategoriesChangeParent = (event, newValue) => {
    const idValues = newValue.map((option) => option.id).join(',');
    setcategoriesidParent(idValues) 
  };
  
  const { businessesCategoriesParent, businessesCategoriesParentLoading } =
    useGetBusinessByCategorieschildrens(categoriesid,1)
  const { businessesCategories: Categories, businessesCategoriesLoading } =
    useGetBusinessByCategories(1);
  const {  Colors  } =
  useGETFillterColor(categoriesid,categoriesidParent,1);

  const [selected_values, setSelectedValues] = useState([]);

  
  const handleCategoriesChangeparents = (event, newValue) => {
    
    if (categoriesid !== undefined && categoriesidParent !== undefined) {
      const selectedValues = newValue?.flatMap((option) => option.id);
    
      const uniqueSelectedValues = selectedValues.filter(
        (value) => !selected_values.includes(value)
      );
    
      setSelectedValues((prevValues) => [...prevValues, ...uniqueSelectedValues]);
      const idValues = selected_values.map((option) => option).join(',');
      setValue("filters", idValues);
    } else {
      setValue("filters", null);
    }
    
  };
  
  
  

  const renderDetails = (
    <>
      {mdUp && (
        <Grid md={4}>
          <Typography variant="h6" sx={{ mb: 0.5 }}>
          {t("Details")}
          </Typography>
          <Typography variant="body2" sx={{ color: "text.secondary" }}>
          {t("Title, short description, image...")}
          </Typography>
        </Grid>
      )}

      <Grid xs={12} md={8}>
        <Card>
          {!mdUp && <CardHeader title="Details" />}

          <Stack spacing={3} sx={{ p: 3 }}>
            <RHFTextField name="name"
            placeholder={t('Name of Store')}
            type="text"
            InputLabelProps={{ shrink: true }}
             label={t("Store Name *")}
             onBlur={() => trigger("name")} // Trigger validation on blur
             inputProps={{ maxLength: 100 }} // Limit input length to 100 characters
             onKeyUp={() => trigger("name")} />

            <RHFTextField
              name="description"
              label={t("Description *")}
              InputLabelProps={{ shrink: true }}
              placeholder={t('Description of Store')}

              multiline
              rows={4}
              onKeyUp={() => trigger("description")}
              onBlur={() => trigger("description")} // Trigger validation on blur
              inputProps={{ maxLength: 500 }}
            />
            <Stack spacing={1.5}>
              <Typography variant="subtitle">{t("Cover Image")}</Typography>
              <RHFUploadAvatar
                name="image"
                maxSize={3145728}
                onDrop={handleDropCover}
                helperText={
                  <Typography
                    variant="caption"
                    sx={{
                      mt: 3,
                      mx: "auto",
                      display: "block",
                      textAlign: "center",
                      color: "text.disabled",
                    }}
                  >
                    {t("Allowed *.jpeg, *.jpg, *.png, *.gif")}
                    <br /> {t("max size of")} {fData(3145728)}
                  </Typography>
                }
              />
            </Stack>

                <Stack spacing={1.5}>
                  {/* <Typography variant="subtitle2">Sub Images</Typography> */}
                  {/* <RHFUpload
                    multiple
                    thumbnail
                    name="images"
                    maxSize={3145728}
                    onDrop={handleDrop}
                    onRemove={handleRemoveFile}
                    onRemoveAll={handleRemoveAllFiles}
                    onUpload={() => console.info("ON UPLOAD")}
                  /> */}
                </Stack>
          </Stack>
        </Card>
      </Grid>
    </>
  );

  const renderProperties = (
    <>
      {mdUp && (
        <Grid md={4}>
          <Typography variant="h6" sx={{ mb: 0.5 }}>
          {t("Properties")}
          </Typography>
          <Typography variant="body2" sx={{ color: "text.secondary" }}>
          {t("Additional Categories,Address and country ....")}
          </Typography>
        </Grid>
      )}

      <Grid xs={12} md={8}>
        <Card>
          {!mdUp && <CardHeader title="Properties" />}

          <Stack spacing={3} sx={{ p: 3 }}>
            <Box
              columnGap={2}
              rowGap={3}
              display="grid"
              gridTemplateColumns={{
                xs: "repeat(1, 1fr)",
                md: "repeat(2, 1fr)",
              }}
            >
                 <RHFTextField name="store_id" label={t("Store Code *")}     placeholder={t("Store Code")}
                onKeyUp={() => trigger("store_id")}
                onBlur={() => trigger("store_id")} 
                type="text"
                InputLabelProps={{ shrink: true }} />

              <RHFTextField
                name="address"
                label={t("Address *")}
                placeholder={t("Address")}
                onKeyUp={() => trigger("address")}
                onBlur={() => trigger("address")} 
                type="text"
                InputLabelProps={{ shrink: true }}
              />

                   <RHFSelect
        native
        name="country_id"
        label={t("Country")}
        value={selectedCountry}
        InputLabelProps={{ shrink: true }}
        onChange={handleCountryChange}
      >
          <option value="" disabled selected>{t("Please select Your Country")}</option> {/* Default option */}

        {counteries.map((country) => (
          <option key={country.id} value={country.id}>
            {country.name}
           
          </option>
          
        ))}
      </RHFSelect>

      <>
  {cities?.length > 0 ? (
    <RHFSelect
      native
      name="city_id" 
      label={t("City")}
      value={selectedCity}
      onChange={handleCityChange}
      InputLabelProps={{ shrink: true }}
    >
      <option value="" disabled>Please select a city</option> 
      {cities.map((city) => (
        <option key={city.id} value={city.id}>
          {city.name}
        </option>
      ))}
    </RHFSelect>
  ) : (
    <RHFSelect
      native
      name="city_id"
      label={t("City")}
      value="" 
      InputLabelProps={{ shrink: true }}
      disabled 
    >
      <option>{t("No cities available")}</option>
    </RHFSelect>
  )}
</>
      <>
  {Rigion?.length > 0 ? (
    <RHFSelect
      native
      name="region_id" 
      label={t("Region")}
      value={SelectedRegion}
      onChange={handleRegionChange}
      InputLabelProps={{ shrink: true }}
    >
      <option value="" disabled>{t("Please select a Region")}</option> 
      {Rigion.map((rigion) => (
        <option key={rigion.id} value={rigion.id}>
          {rigion.name}
        </option>
      ))}
    </RHFSelect>
  ) : (
    <RHFSelect
      native
      name="region_id" 
      label={t("Region")}
      value="" 
      InputLabelProps={{ shrink: true }}
      disabled 
    >
      <option>{t("No Regions available")}</option>
    </RHFSelect>
  )}
</>
<RHFSelect
      native
      name="Categories" 
      label={t("Main Categories")}
      placeholder={t("Main Categories")}
      value={categoriesid}
      onChange={handleCategoriesChange}
      InputLabelProps={{ shrink: true }}
    >
      <option value="" disabled>{t("Please select a Main categories")}</option> 
      {Categories.map((rigion) => (
        <option key={rigion.id} value={rigion.id}>
          {rigion.name}
        </option>
      ))}
    </RHFSelect>

<RHFAutocomplete
  name="Subcategories"
  label={categoriesid == '' ?t("Please Select Main Category First"):t("SubCategories")}
  placeholder={categoriesid == '' ?t("Please Select Main Category First"):t("SubCategories")}
  multiple
  freeSolo
  options={categoriesid !== '' ? businessesCategoriesParent.map((option) => ({
    id: option.id,
    name: option.name,
  })) : []} 
  onChange={handleCategoriesChangeParent} 
  getOptionLabel={(option) => option.name}
  renderOption={(props, option) => (
    <li {...props} key={option.id} value={option.name}>
      {option.name}
    </li>
  )}
  renderTags={(selected, getTagProps) =>
    selected?.map((option, index) => (
      <Chip
        {...getTagProps({ index })}
        key={index}
        label={option.name}
        value={option.id} 
        size="small"
        color="info"
        variant="soft"
      />
    ))
  }
  disabled={categoriesid === ''} // Disable the component if categoriesId is undefined
/>

            </Box>
            <Stack>
              
            <Grid>
                {!displayMap === false && (
                  <BusinessMap onLocationChange={handleLocationChange} />
                )}
              </Grid>
              <Grid>
                
                <LoadingButton
                  variant="contained"
                  size="large"
                  onClick={butonLocation}
                  style={{ display: displayMap ? "none" : "visible" }}
                >
                  {t("Choose Your Location")}
                </LoadingButton>
                <LoadingButton
                  variant="contained"
                  size="large"
                  onClick={slectLocation}
                  style={{ display: selectedLocation ? "block" : "none" }}
                >
                  {!displayMap ? t("Edit Your Location ") : t("Done")}
                </LoadingButton>
              </Grid>
            </Stack>
        

          </Stack>
        </Card>
      </Grid>
    </>
  );

  const renderlinkes = (
    <>
      {mdUp && (
        <Grid md={4}>
          <Typography variant="h6" sx={{ mb: 0.5 }}>
            {t("contact")}
          </Typography>
          <Typography variant="body2" sx={{ color: "text.secondary" }}>
            {t("Additional Your social media sites and your numbers...")}
          </Typography>
        </Grid>
      )}

      <Grid xs={12} md={8}>
        <Card>
          {!mdUp && <CardHeader title="Properties" />}

          <Stack spacing={3} sx={{ p: 3 }}>
            <Box
              columnGap={2}
              rowGap={3}
              display="grid"
              gridTemplateColumns={{
                xs: "repeat(1, 1fr)",
                md: "repeat(2, 1fr)",
              }}
            >
              
              <RHFTextField
                name="email"
                label={t("Email *")}
                placeholder={t("Email")}
                type="email"
                onKeyUp={() => trigger("email")}
                onBlur={() => trigger("email")}
                InputLabelProps={{ shrink: true }}
              />
 <RHFTextField
  name="mobile_number"
  label={t("Mobile Number *")}
  placeholder={t("Mobile Number")}
  type="text"
  onKeyUp={() => trigger("mobile_number")}
  onBlur={() => trigger("mobile_number")}
  InputLabelProps={{ shrink: true }}
/>
              <RHFTextField
                name="website"
                label={t("Website")}
                placeholder={t("Website")}
                type="text"
                InputLabelProps={{ shrink: true }}
              />
              <RHFTextField
                name="facebook"
                label={t("facebook")}
                placeholder={t("facebook")}
                type="text"
                InputLabelProps={{ shrink: true }}
              />
              <RHFTextField
                name="instagram"
                label={t("instgram")}
                placeholder={t("instgram")}
                type="text"
                InputLabelProps={{ shrink: true }}
              />
              <RHFTextField
                name="whatsapp"
                label={t("Whatsapp")}
                placeholder={t("Whatsapp")}
                type="text"
                InputLabelProps={{ shrink: true }}
              />

              <RHFTextField
                name="snapchat"
                label={t("snapchat")}
                placeholder={t("snapchat")}
                type="text"
                InputLabelProps={{ shrink: true }}
              />
            </Box>
          </Stack>
        </Card>
      </Grid>
    </>
  );
  const renderFilters = (
    <>
      {mdUp && (
        <Grid md={4}>
          <Typography variant="h6" sx={{ mb: 0.5 }}>
          {t("Filters")} 
          </Typography>
          <Typography variant="body2" sx={{ color: "text.secondary" }}>
          {t("Additional Filters")}
          </Typography>
        </Grid>
      )}

      <Grid xs={12} md={8}>
        <Card>
          {!mdUp && <CardHeader title="Properties" />}

          <Stack spacing={3} sx={{ p: 3 }}>
            <Box
              columnGap={2}
              rowGap={3}
              display="grid"
              gridTemplateColumns={{
                xs: "repeat(1, 1fr)",
                md: "repeat(2, 1fr)",
              }}
            >

               
               


              {Colors?.length>0?<>
{Colors?.map((name) => {
  if (categoriesid === undefined || categoriesidParent === undefined) {
    return (
      <RHFAutocomplete
        key={name?.filterMaster.id}
        // name="filters"
        label={name?.filterMaster.name}
        placeholder={name?.filterMaster.name}
        multiple
        freeSolo
        options={name?.filterDetails.map((option) => ({
          id: option.id,
          name: option.name,
        }))}
        getOptionLabel={(option) => option.name}
        renderOption={(props, option) => (
          <li {...props} key={option.id} value={option.name}>
            {option.name}
          </li>
        )}
        renderTags={(selected, getTagProps) =>
          selected?.map((option, index) => (
            <Chip
              {...getTagProps({ index })}
              key={index}
              label={option.name}
              value={option.id}
              size="small"
              color="info"
              variant="soft"
            />
          ))
        }
        disabled // Disable the component
      />
    );
  } else {
    return (
      <RHFAutocomplete
      key={name?.filterMaster.id}
      name="filters"
      label={name?.filterMaster.name}
      placeholder={name?.filterMaster.name}
      multiple
      freeSolo
      options={name?.filterDetails.map((option) => ({
        id: option.id,
        name: option.name,
      }))}
      onChange={handleCategoriesChangeparents}
      getOptionLabel={(option) => option.name}
      renderOption={(props, option) => (
        <li {...props} key={option.id} value={option.name}>
          {option.name}
        </li>
      )}
      renderTags={(selected, getTagProps) =>
        selected
          ? selected
              .filter((option, index, self) => self.findIndex((o) => o.id === option.id) === index)
              .map((option, index) => (
                <Chip
                  {...getTagProps({ index })}
                  key={index}
                  label={option.name}
                  value={option.id}
                  size="small"
                  color="info"
                  variant="soft"
                />
              ))
          : null
      }
    />
    
    
    
    );
  }
})}
              </>:
              

              <>
          <Typography variant="h6" sx={{ mb: 0.5 }}>
          {t("Choose Categories Then Choose  Filters")} 
          </Typography>

         <CircularProgress />
     </>}
      

          
              
             
            </Box>
          </Stack>
        </Card>
      </Grid>
    </>
  );
  const renderActions = (
    <>
      {mdUp && <Grid md={4} />}
      <Grid xs={12} md={8} sx={{ display: "flex", alignItems: "center" }}>
      <FormControlLabel
      control={<Switch checked={isFoodStaff} onChange={handleSwitchChange} />}
      label={t("is Food Staff")}
      sx={{ flexGrow: 1, pl: 3 }}
    />

        <LoadingButton
          type="submit"
          variant="contained"
          size="large"
          loading={isSubmitting}
        >
          {!currentBusiness ? t("Create Store") : t("Save Changes")}
        </LoadingButton>
      </Grid>
    </>
  );

  return (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <Grid container spacing={3}>
        {renderDetails}

        {renderProperties}
        {renderFilters}
        {renderlinkes}
        {renderActions}
      </Grid>
    </FormProvider>
  );
}

BusinessNewEditForm.propTypes = {
  currentBusiness: PropTypes.object,
};
