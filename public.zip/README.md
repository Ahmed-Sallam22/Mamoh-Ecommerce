## NODE.JS

- Node 16.x || 18.x

## USING YARN (Recommend)

- yarn install

- cp .env.example .env

- yarn start

## USING NPM

- npm i OR npm i --legacy-peer-deps

- cp .env.example .env

- npm start
#   W o r k i n g  
 